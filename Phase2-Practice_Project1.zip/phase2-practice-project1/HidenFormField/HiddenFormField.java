import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionServlet")
public class HiddenFormField extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the username from the form submission
        String username = request.getParameter("username");

        // Get the session ID from the hidden form field
        String sessionId = request.getParameter("sessionId");

        // Display the session ID and username on the web page
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h1>Session ID: " + sessionId + "</h1>");
        response.getWriter().println("<h2>Username: " + username + "</h2>");
        response.getWriter().println("</body></html>");
    }
}
