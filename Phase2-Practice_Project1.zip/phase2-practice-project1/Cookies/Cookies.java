import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;

@WebServlet("/SessionServlet")
public class Cookies extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the username from the form submission
        String username = request.getParameter("username");

        // Generate a session ID (you can use more sophisticated techniques)
        String sessionId = "SESSION_" + System.currentTimeMillis();

        // Create a cookie to store the session ID
        Cookie cookie = new Cookie("sessionId", sessionId);
        cookie.setMaxAge(3600); // Set the cookie's maximum age (in seconds)

        // Add the cookie to the response
        response.addCookie(cookie);

        // Display the session ID on the web page
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h1>Session ID: " + sessionId + "</h1>");
        response.getWriter().println("</body></html>");
    }
}
