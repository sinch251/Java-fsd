import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import java.io.IOException;

//@WebFilter("/Filters");
public class Filters implements Filter {
    public void init(FilterConfig config) throws ServletException {
        // Initialization code if needed
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        // Log information about the incoming request
        System.out.println("Request received at " + new java.util.Date());
        System.out.println("Remote Host: " + request.getRemoteHost());
        System.out.println("Remote Address: " + request.getRemoteAddr());
        System.out.println("Request URI: " + ((HttpServletRequest) request).getRequestURI());

        // Continue the filter chain
        chain.doFilter(request, response);
    }

    public void destroy() {
        // Cleanup code if needed
    }
}
