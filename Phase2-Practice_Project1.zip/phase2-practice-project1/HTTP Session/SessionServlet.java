import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the username from the form submission
        String username = request.getParameter("username");

        // Get the session (create a new session if it doesn't exist)
        HttpSession session = request.getSession();

        // Retrieve or create a session ID and store it in the session
        String sessionId = (String) session.getAttribute("sessionId");
        if (sessionId == null) {
            sessionId = "SESSION_" + System.currentTimeMillis();
            session.setAttribute("sessionId", sessionId);
        }

        // Display the session ID on the web page
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h1>Session ID: " + sessionId + "</h1>");
        response.getWriter().println("<h2>Username: " + username + "</h2>");
        response.getWriter().println("</body></html>");
    }
}
