import java.io.IOException;
import javax.servlet.GenericServlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;


@WebServlet("/generic-demo")
public class MyGenericServlet extends GenericServlet {

    @Override
    public void service(ServletRequest request, ServletResponse response) throws IOException {
        // Get the servlet context to set content type and write response
        response.setContentType("text/html");

        // Get a parameter from the request
        String name = request.getParameter("name");

        // Write a simple HTML response
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h2>Hello, " + name + "!</h2>");
        response.getWriter().println("</body></html>");
    }
}
