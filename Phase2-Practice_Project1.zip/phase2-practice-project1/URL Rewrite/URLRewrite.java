import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionServlet")
public class URLRewrite extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the username from the form submission
        String username = request.getParameter("username");

        // Generate a session ID (you can use more sophisticated techniques)
        String sessionId = "SESSION_" + System.currentTimeMillis();

        // Append the session ID to the URL
        String redirectUrl = "index.html?sessionId=" + sessionId;

        // Redirect to the updated URL
        response.sendRedirect(redirectUrl);
    }
}
