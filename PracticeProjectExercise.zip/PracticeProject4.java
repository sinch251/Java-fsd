public class ConstructorDemo {
    // Default Constructor
    public ConstructorDemo() {
        System.out.println("Default Constructor");
    }

    // Parameterized Constructor
    public ConstructorDemo(String message) {
        System.out.println("Parameterized Constructor: " + message);
    }

    // Constructor Chaining
    public ConstructorDemo(int value) {
        this("Chaining Constructor");
        System.out.println("Constructor Chaining: " + value);
    }

    public static void main(String[] args) {
        // Creating objects using different constructors

        // 1. Using the Default Constructor
        ConstructorDemo defaultConstructor = new ConstructorDemo();

        // 2. Using the Parameterized Constructor
        ConstructorDemo parameterizedConstructor = new ConstructorDemo("Hello, World!");

        // 3. Using Constructor Chaining
        ConstructorDemo chainingConstructor = new ConstructorDemo(42);
    }
}