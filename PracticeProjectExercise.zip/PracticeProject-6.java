import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapDemo {
    public static void main(String[] args) {
        // HashMap - An unordered map
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Alice", 25);
        hashMap.put("Bob", 30);
        hashMap.put("Charlie", 22);

        System.out.println("HashMap Elements:");
        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }

        // TreeMap - A sorted map (sorted by keys)
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Zack", 28);
        treeMap.put("John", 35);
        treeMap.put("Emily", 29);

        System.out.println("\nTreeMap Elements:");
        for (Map.Entry<String, Integer> entry : treeMap.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
    }
}